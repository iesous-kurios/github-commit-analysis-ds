'''Create APP'''
from api.app import createApp

application = createApp()